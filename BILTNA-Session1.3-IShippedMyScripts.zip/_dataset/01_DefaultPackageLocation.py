import sys

pyt_path = r'C:\Program Files (x86)\IronPython 2.7\Lib'
sys.path.append(pyt_path)

import os
OUT = os.getenv('APPDATA') + '\Dynamo\Dynamo Revit\\1.3\packages'